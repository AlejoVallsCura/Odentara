const express = require("express");

const prisma = require("../lib/prisma");
const { logDeleteAudit } = require("../lib/audit");
const { requireAuth } = require("../middleware/auth");
const {
  canAccessWholeClinic,
  getAccessibleProfessionalIds,
  canManageAppointments,
  canEditAppointments,
} = require("../lib/permissions");

const router = express.Router();

const VALID_STATUSES = new Set(["not_sent", "sent", "confirmed", "rescheduled", "cancelled"]);
const VALID_CHANNELS = new Set(["whatsapp", "phone", "email", "manual"]);
const BUSINESS_TIME_ZONE = "America/Buenos_Aires";

function getBusinessNowParts() {
  const formatter = new Intl.DateTimeFormat("en-CA", {
    timeZone: BUSINESS_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  });

  const parts = formatter.formatToParts(new Date());
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));

  return {
    year: Number(values.year),
    month: Number(values.month),
    day: Number(values.day),
    hour: Number(values.hour),
    minute: Number(values.minute),
  };
}

function getTodayIsoLocal() {
  const now = getBusinessNowParts();
  const year = now.year;
  const month = String(now.month).padStart(2, "0");
  const day = String(now.day).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function parseDateOnly(dateStr) {
  const [year, month, day] = String(dateStr).split("-").map(Number);
  return new Date(year, (month || 1) - 1, day || 1);
}

function formatLocalDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function formatLocalTime(date) {
  return `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
}

function parseDateTime(dateStr, timeStr) {
  const [year, month, day] = String(dateStr).split("-").map(Number);
  const [hours, minutes] = String(timeStr).split(":").map(Number);
  return new Date(year, (month || 1) - 1, day || 1, hours || 0, minutes || 0, 0, 0);
}

function timeToMinutes(timeStr = "") {
  const [hours, minutes] = String(timeStr).split(":").map(Number);
  if (Number.isNaN(hours) || Number.isNaN(minutes)) return null;
  return hours * 60 + minutes;
}

function currentMinutes() {
  const now = getBusinessNowParts();
  return now.hour * 60 + now.minute;
}

function getAppointmentEndMinutes(payload) {
  const start = timeToMinutes(payload.time);
  if (start === null) return null;
  const duration = payload.isOverbook ? 15 : Number(payload.durationMinutes || 0);
  return start + duration;
}

function scheduleAllowsAppointment(schedules = [], payload) {
  const start = timeToMinutes(payload.time);
  const end = getAppointmentEndMinutes(payload);
  if (start === null || end === null) return false;

  const weekday = parseDateOnly(payload.date).getDay();
  return schedules.some((item) => {
    if (!item.active || item.weekday !== weekday) return false;
    const scheduleStart = timeToMinutes(item.startTime);
    const scheduleEnd = timeToMinutes(item.endTime);
    if (scheduleStart === null || scheduleEnd === null) return false;
    return start >= scheduleStart && end <= scheduleEnd;
  });
}

function buildAppointmentAccessWhere(permissions) {
  if (canAccessWholeClinic(permissions)) {
    return {};
  }

  const ids = getAccessibleProfessionalIds(permissions);
  if (ids.length === 0) {
    return { id: -1 };
  }

  return {
    professionalId: { in: ids },
  };
}

function serializeAppointment(appointment) {
  return {
    id: appointment.id,
    patientId: appointment.patientId,
    professionalId: appointment.professionalId,
    createdByUserId: appointment.createdByUserId,
    date: formatLocalDate(appointment.date),
    startTime: formatLocalTime(appointment.startTime),
    durationMinutes: appointment.durationMinutes,
    status: appointment.status,
    isOverbook: appointment.isOverbook,
    confirmationChannel: appointment.confirmationChannel,
    confirmationSentAt: appointment.confirmationSentAt,
    confirmationResponseAt: appointment.confirmationResponseAt,
    cancellationReason: appointment.cancellationReason,
    notes: appointment.notes,
    createdAt: appointment.createdAt,
    updatedAt: appointment.updatedAt,
    patient: appointment.patient
      ? {
          id: appointment.patient.id,
          fullName: appointment.patient.fullName,
          dni: appointment.patient.dni,
          phone: appointment.patient.phone,
        }
      : null,
    professional: appointment.professional
      ? {
          id: appointment.professional.id,
          fullName: appointment.professional.fullName,
          color: appointment.professional.color,
        }
      : null,
    createdByUser: appointment.createdByUser
      ? {
          id: appointment.createdByUser.id,
          email: appointment.createdByUser.email,
          fullName: appointment.createdByUser.fullName,
        }
      : null,
  };
}

async function ensureAccessibleProfessional(permissions, professionalId) {
  if (canAccessWholeClinic(permissions)) {
    return true;
  }

  const ids = getAccessibleProfessionalIds(permissions);
  return ids.includes(professionalId);
}

async function validateAppointmentPayload(
  payload,
  permissions,
  currentAppointmentId = null,
  existingAppointment = null
) {
  if (!payload.patientId || !payload.professionalId || !payload.date || !payload.time) {
    return "Paciente, profesional, fecha y hora son obligatorios.";
  }

  if (!(await ensureAccessibleProfessional(permissions, payload.professionalId))) {
    return "No tenes acceso al profesional seleccionado.";
  }

  const patient = await prisma.patient.findUnique({
    where: { id: payload.patientId },
    select: { id: true, deletedAt: true },
  });

  if (!patient || patient.deletedAt) {
    return "El paciente seleccionado no existe.";
  }

  const professional = await prisma.professional.findUnique({
    where: { id: payload.professionalId },
    select: { id: true, active: true, deletedAt: true, schedules: true },
  });

  const validDurations = payload.isOverbook ? [15] : [30, 60, 90, 120];
  if (!validDurations.includes(Number(payload.durationMinutes || 0))) {
    return payload.isOverbook
      ? "El sobreturno solo puede durar 15 minutos."
      : "La duración del turno no es válida.";
  }

  if (!professional || professional.deletedAt || !professional.active) {
    return "El profesional seleccionado no existe o está inactivo.";
  }

  const keepsSameSlot =
    existingAppointment &&
    formatLocalDate(existingAppointment.date) === payload.date &&
    formatLocalTime(existingAppointment.startTime) === payload.time &&
    existingAppointment.professionalId === payload.professionalId &&
    existingAppointment.patientId === payload.patientId &&
    existingAppointment.isOverbook === payload.isOverbook;

  const todayIso = getTodayIsoLocal();
  if (payload.date < todayIso && !keepsSameSlot) {
    return "No se pueden crear turnos para dias anteriores.";
  }

  if (payload.date === todayIso) {
    const selectedMinutes = timeToMinutes(payload.time);

    if (
      selectedMinutes !== null &&
      selectedMinutes < currentMinutes() &&
      !payload.isOverbook &&
      !keepsSameSlot
    ) {
      return "Los horarios pasados de hoy solo admiten sobreturnos.";
    }
  }

  if (!scheduleAllowsAppointment(professional.schedules || [], payload)) {
    return "La duración elegida no entra dentro del horario disponible del profesional.";
  }

  const existingAppointments = await prisma.appointment.findMany({
    where: {
      professionalId: payload.professionalId,
      date: parseDateOnly(payload.date),
      deletedAt: null,
      status: { notIn: ["cancelled", "rescheduled"] },
      ...(currentAppointmentId ? { id: { not: currentAppointmentId } } : {}),
    },
    select: { id: true, isOverbook: true, startTime: true, durationMinutes: true },
  });

  const start = timeToMinutes(payload.time);
  const end = getAppointmentEndMinutes(payload);
  if (start === null || end === null) {
    return "La hora seleccionada no es válida.";
  }

  const hasOverlap = existingAppointments.some((item) => {
    const existingStart = item.startTime.getHours() * 60 + item.startTime.getMinutes();
    const existingEnd = existingStart + item.durationMinutes;

    if (payload.isOverbook) {
      if (!item.isOverbook) return false;
      return start < existingEnd && end > existingStart;
    }

    if (item.isOverbook) return false;
    return start < existingEnd && end > existingStart;
  });

  if (hasOverlap) {
    return payload.isOverbook
      ? "Ya existe un sobreturno en ese horario para el profesional."
      : "Ese rango horario ya está ocupado para el profesional.";
  }

  return null;
}

router.get("/", requireAuth, async (req, res) => {
  try {
    const date = String(req.query.date || "").trim();
    const professionalId = req.query.professionalId ? Number(req.query.professionalId) : null;
    const patientSearch = String(req.query.q || "").trim();

    const filters = [];

    if (date) {
      filters.push({ date: parseDateOnly(date) });
    }

    if (professionalId) {
      filters.push({ professionalId });
    }

    if (patientSearch) {
      filters.push({
        patient: {
          OR: [
            { fullName: { contains: patientSearch, mode: "insensitive" } },
            { dni: { contains: patientSearch.replace(/\D/g, "") } },
          ],
        },
      });
    }

    const appointments = await prisma.appointment.findMany({
      where: {
        AND: [buildAppointmentAccessWhere(req.permissions), ...filters],
      },
      orderBy: [{ date: "asc" }, { startTime: "asc" }],
      include: {
        patient: {
          select: { id: true, fullName: true, dni: true, phone: true },
        },
        professional: {
          select: { id: true, fullName: true, color: true },
        },
        createdByUser: {
          select: { id: true, email: true, fullName: true },
        },
      },
    });

    return res.json({
      ok: true,
      appointments: appointments.map(serializeAppointment),
    });
  } catch (_error) {
    return res.status(500).json({ ok: false, error: "No se pudieron listar los turnos." });
  }
});

router.get("/:id", requireAuth, async (req, res) => {
  try {
    const appointment = await prisma.appointment.findFirst({
      where: {
        id: Number(req.params.id),
        ...buildAppointmentAccessWhere(req.permissions),
      },
      include: {
        patient: {
          select: { id: true, fullName: true, dni: true, phone: true },
        },
        professional: {
          select: { id: true, fullName: true, color: true },
        },
        createdByUser: {
          select: { id: true, email: true, fullName: true },
        },
      },
    });

    if (!appointment) {
      return res.status(404).json({ ok: false, error: "Turno no encontrado o sin acceso." });
    }

    return res.json({
      ok: true,
      appointment: serializeAppointment(appointment),
    });
  } catch (_error) {
    return res.status(500).json({ ok: false, error: "No se pudo obtener el turno." });
  }
});

router.post("/", requireAuth, async (req, res) => {
  try {
    if (!canManageAppointments(req.permissions)) {
      return res.status(403).json({ ok: false, error: "No tenes permisos para crear turnos." });
    }

    const payload = {
      patientId: Number(req.body.patientId),
      professionalId: Number(req.body.professionalId),
      date: String(req.body.date || "").trim(),
      time: String(req.body.time || "").trim(),
      durationMinutes: Number(req.body.durationMinutes || 30),
      status: VALID_STATUSES.has(req.body.status) ? req.body.status : "not_sent",
      isOverbook: Boolean(req.body.isOverbook),
      confirmationChannel: VALID_CHANNELS.has(req.body.confirmationChannel)
        ? req.body.confirmationChannel
        : null,
      confirmationSentAt: req.body.confirmationSentAt ? new Date(req.body.confirmationSentAt) : null,
      confirmationResponseAt: req.body.confirmationResponseAt
        ? new Date(req.body.confirmationResponseAt)
        : null,
      cancellationReason: req.body.cancellationReason ? String(req.body.cancellationReason).trim() : null,
      notes: req.body.notes ? String(req.body.notes).trim() : null,
    };

    const validationError = await validateAppointmentPayload(payload, req.permissions);
    if (validationError) {
      return res.status(400).json({ ok: false, error: validationError });
    }

    const appointment = await prisma.appointment.create({
      data: {
        patientId: payload.patientId,
        professionalId: payload.professionalId,
        createdByUserId: req.user.id,
        date: parseDateOnly(payload.date),
        startTime: parseDateTime(payload.date, payload.time),
        durationMinutes: payload.durationMinutes,
        status: payload.status,
        isOverbook: payload.isOverbook,
        confirmationChannel: payload.confirmationChannel,
        confirmationSentAt: payload.confirmationSentAt,
        confirmationResponseAt: payload.confirmationResponseAt,
        cancellationReason: payload.cancellationReason,
        notes: payload.notes,
        deletedAt: null,
      },
      include: {
        patient: {
          select: { id: true, fullName: true, dni: true, phone: true },
        },
        professional: {
          select: { id: true, fullName: true, color: true },
        },
        createdByUser: {
          select: { id: true, email: true, fullName: true },
        },
      },
    });

    return res.status(201).json({
      ok: true,
      appointment: serializeAppointment(appointment),
    });
  } catch (_error) {
    return res.status(500).json({ ok: false, error: "No se pudo crear el turno." });
  }
});

router.put("/:id", requireAuth, async (req, res) => {
  try {
    if (!canEditAppointments(req.permissions)) {
      return res.status(403).json({ ok: false, error: "No tenes permisos para editar turnos." });
    }

    const appointmentId = Number(req.params.id);
    const existing = await prisma.appointment.findFirst({
      where: {
        id: appointmentId,
        ...buildAppointmentAccessWhere(req.permissions),
      },
    });

    if (!existing) {
      return res.status(404).json({ ok: false, error: "Turno no encontrado o sin acceso." });
    }

    const payload = {
      patientId: Number(req.body.patientId ?? existing.patientId),
      professionalId: Number(req.body.professionalId ?? existing.professionalId),
      date: String(req.body.date || formatLocalDate(existing.date)).trim(),
      time: String(req.body.time || formatLocalTime(existing.startTime)).trim(),
      durationMinutes: Number(req.body.durationMinutes ?? existing.durationMinutes),
      status: VALID_STATUSES.has(req.body.status) ? req.body.status : existing.status,
      isOverbook: req.body.isOverbook !== undefined ? Boolean(req.body.isOverbook) : existing.isOverbook,
      confirmationChannel: req.body.confirmationChannel
        ? VALID_CHANNELS.has(req.body.confirmationChannel)
          ? req.body.confirmationChannel
          : null
        : existing.confirmationChannel,
      confirmationSentAt:
        req.body.confirmationSentAt !== undefined
          ? req.body.confirmationSentAt
            ? new Date(req.body.confirmationSentAt)
            : null
          : existing.confirmationSentAt,
      confirmationResponseAt:
        req.body.confirmationResponseAt !== undefined
          ? req.body.confirmationResponseAt
            ? new Date(req.body.confirmationResponseAt)
            : null
          : existing.confirmationResponseAt,
      cancellationReason:
        req.body.cancellationReason !== undefined
          ? req.body.cancellationReason
            ? String(req.body.cancellationReason).trim()
            : null
          : existing.cancellationReason,
      notes:
        req.body.notes !== undefined ? (req.body.notes ? String(req.body.notes).trim() : null) : existing.notes,
    };

    const validationError = await validateAppointmentPayload(
      payload,
      req.permissions,
      appointmentId,
      existing
    );
    if (validationError) {
      return res.status(400).json({ ok: false, error: validationError });
    }

    const appointment = await prisma.appointment.update({
      where: { id: appointmentId },
      data: {
        patientId: payload.patientId,
        professionalId: payload.professionalId,
        date: parseDateOnly(payload.date),
        startTime: parseDateTime(payload.date, payload.time),
        durationMinutes: payload.durationMinutes,
        status: payload.status,
        isOverbook: payload.isOverbook,
        confirmationChannel: payload.confirmationChannel,
        confirmationSentAt: payload.confirmationSentAt,
        confirmationResponseAt: payload.confirmationResponseAt,
        cancellationReason: payload.cancellationReason,
        notes: payload.notes,
        deletedAt: null,
      },
      include: {
        patient: {
          select: { id: true, fullName: true, dni: true, phone: true },
        },
        professional: {
          select: { id: true, fullName: true, color: true },
        },
        createdByUser: {
          select: { id: true, email: true, fullName: true },
        },
      },
    });

    return res.json({
      ok: true,
      appointment: serializeAppointment(appointment),
    });
  } catch (_error) {
    return res.status(500).json({ ok: false, error: "No se pudo actualizar el turno." });
  }
});

router.delete("/:id", requireAuth, async (req, res) => {
  try {
    if (!canManageAppointments(req.permissions)) {
      return res.status(403).json({ ok: false, error: "No tenes permisos para eliminar turnos." });
    }

    const appointment = await prisma.appointment.findFirst({
      where: {
        id: Number(req.params.id),
        ...buildAppointmentAccessWhere(req.permissions),
      },
      select: { id: true },
    });

    if (!appointment) {
      return res.status(404).json({ ok: false, error: "Turno no encontrado o sin acceso." });
    }

    const existing = await prisma.appointment.findUnique({
      where: { id: appointment.id },
      include: {
        patient: true,
        professional: true,
      },
    });

    await prisma.appointment.update({
      where: { id: appointment.id },
      data: {
        status: "cancelled",
        deletedAt: new Date(),
      },
    });

    await logDeleteAudit(prisma, req.user.id, "Appointment", appointment.id, {
      appointment: existing,
    });

    return res.json({
      ok: true,
      message: "Turno eliminado correctamente.",
    });
  } catch (error) {
    const message =
      error?.code === "P2003"
        ? "No se puede eliminar el turno porque tiene registros relacionados."
        : "No se pudo eliminar el turno.";
    return res.status(400).json({ ok: false, error: message });
  }
});

module.exports = router;
